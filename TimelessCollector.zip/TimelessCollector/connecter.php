<?php
require("bd.php");

$email = isset($_POST['mail']) ? $_POST['mail'] : '';
$mdp = isset($_POST['mdp1']) ? $_POST['mdp1'] : '';

$bdd = getBD();
session_start();

$query = $bdd->prepare('SELECT * FROM clients WHERE mail = :email');
$query->bindParam(':email', $email, PDO::PARAM_STR);
$query->execute();
$client = $query->fetch(PDO::FETCH_ASSOC);

if ($client) {
    $mdp_hash = $client['mdp'];
    if (password_verify($mdp, $mdp_hash)) {
       
        $_SESSION['client'] = $client;
        echo json_encode(['success' => true, 'message' => 'Connexion réussie']);
    } else {

        echo json_encode(['success' => false, 'message' => 'Mot de passe incorrect']);
    }
} else {

    echo json_encode(['success' => false, 'message' => 'Utilisateur introuvable']);
}
?>
