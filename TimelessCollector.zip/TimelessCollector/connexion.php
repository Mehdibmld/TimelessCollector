<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TimelessCollector - Connexion</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Croissant+One&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('form').submit(function(event) {
                event.preventDefault();

                var userData = $('form').serialize();
                $.ajax({
                    type: 'POST',
                    url: 'connecter.php',
                    data: userData,
                    success: function(response) {

                        console.log(response);
                        var result = JSON.parse(response);
                        if (result.success) {

                            window.location.href = 'index.php';
                        } else {
                           
                            alert(result.message);
                        }
                    },
                    error: function(error) {
 
                        console.log(error);
                    }
                });
            });
        });
    </script>
</head>
<body>
    <a href="index.php">
        <h1 class="Titre">TimelessCollector</h1>
    </a>

    <p>Connectez-vous à votre compte :</p>

    <form>
        <label for="email">Adresse e-mail :</label>
        <input type="email" id="mail" name="mail" required><br><br>
        <label for="motdepasse">Mot de passe :</label>
        <input type="password" id="mdp1" name="mdp1" required><br><br>
        <input type="submit" value="Se connecter" class="ContactBu">
    </form>

    <p class="Al">Si vous n'avez pas encore de compte, <a href="nouveau.php">CLIQUEZ ICI</a> pour vous inscrire.</p>
</body>
</html>
