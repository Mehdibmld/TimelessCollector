function toggleChat() {
    const chatContainer = $('.chat-bottom-right');
    chatContainer.toggleClass('chat-open');
}

$('.open-chat-button').on('click', function() {
    toggleChat();
});

function closeChat() {
    const chatContainer = $('.chat-bottom-right');
    chatContainer.removeClass('chat-open');
}

// Fonction pour échapper les caractères spéciaux HTML
function specialcharsehtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };

    return text.replace(/[&<>"']/g, (m) => map[m]);
}

$(document).ready(function() {
    const getMessages = function() {
        $.ajax({
            type: 'GET',
            url: 'chat.php',
            dataType: 'json',
            success: function(resultat) {
                const html = resultat.reverse().map(function(messages) {
                    const prenom = messages.prenom ? messages.prenom : 'Utilisateur';
                    const content = specialcharsehtml(messages.content);
                    return `
                        <div class="message">
                            <span class="id_client">${prenom} dit :</span>
                            <span class="content">'${content}'</span>
                        </div>`;
                }).join('');

                const messagesContainer = $('.messages');

                messagesContainer.html(html);
                messagesContainer.scrollTop(messagesContainer.prop('scrollHeight'));
            }
        });
    };

    const postMessage = function(event) {
        event.preventDefault();

        const content = specialcharsehtml($('#content').val());

        $.ajax({
            type: 'POST',
            url: 'chat.php?task=write',
            data: { content: content },
            success: function() {
                $('#content').val('');
                $('#content').focus();
                getMessages();
            }
        });
    };

    $('form').submit(postMessage);

    const interval = window.setInterval(getMessages, 3000);

    getMessages();
});
