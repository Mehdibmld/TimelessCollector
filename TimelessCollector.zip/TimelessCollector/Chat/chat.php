<?php
session_start();
require_once('../bd.php');
$bdd = getBD();
$task = "list";


if(array_key_exists("task", $_GET)){
    $task=$_GET['task'];
}

if($task == "write"){
    postMessage();
}
else{
    getMessages();
}


function getMessages(){
    global $bdd;
    
    // Supprimer les messages de plus de 10 minutes
    $deleteQuery = $bdd->prepare("DELETE FROM messages WHERE dates < NOW() - INTERVAL 10 MINUTE");
    $deleteQuery->execute();

    // Requête pour obtenir les messages avec les prénoms des utilisateurs
    $resultats = $bdd->query("
        SELECT messages.message_id, messages.id_client, messages.content, clients.prenom
        FROM messages
        LEFT JOIN clients ON messages.id_client = clients.id_client
        ORDER BY messages.dates DESC
    ");

    // Traitement des messages
    $messages = $resultats->fetchAll(PDO::FETCH_ASSOC);

    // Affichage des données sous forme JSON
    echo json_encode($messages);
}


function postMessage(){
    global $bdd;
    
    if (!array_key_exists('content', $_POST)) {
        echo json_encode(["status" => "error", "message" => "probleme"]);
        return;
    }

    // Récupérer l'ID du client à partir de la session
    $id_client = isset($_SESSION['client']['id_client']) ? $_SESSION['client']['id_client'] : null;

    // Si l'ID du client est disponible, récupérer le prénom depuis la base de données
    if ($id_client) {
        $queryClient = $bdd->prepare("SELECT prenom FROM client WHERE id_client = :id_client");
        $queryClient->execute(['id_client' => $id_client]);
        $client = $queryClient->fetch(PDO::FETCH_ASSOC);

        // Utiliser le prénom du client s'il est disponible
        $prenom = isset($client['prenom']) ? $client['prenom'] : 'Utilisateur';
    } else {
        $prenom = 'Utilisateur';
    }

    $content = isset($_POST["content"]) ? htmlspecialchars($_POST["content"]) : '';

    $query = $bdd->prepare('INSERT INTO messages SET id_client = :id_client, content = :content, dates = NOW()');

    $query->execute([
        "id_client" => $id_client,
        "content" => $content,
    ]);

    echo json_encode(["status" => "success"]);
}




?>