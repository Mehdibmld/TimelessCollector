<?php
session_start();

require_once('./vendor/autoload.php');
require_once('stripe.php');

include "bd.php";
$bdd = getBD();

if (!isset($_SESSION['client'])) {
    header("HTTP/1.1 303 See Other");
    header("Location: connexion.php");
    exit;
}
else{
    $id_client = $_SESSION['client'];
    $id_stripe_utilisateur = $id_client['ID_STRIPE'];

   
    $query_user = $bdd->prepare('SELECT nom, prenom, adresse FROM Clients WHERE id_client = :id_client');
    $query_user->bindParam(':id_client', $id_client, PDO::PARAM_INT);
    $query_user->execute();
    $user_info = $query_user->fetch(PDO::FETCH_ASSOC);

}
?>


<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>TimelessCollector</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Signika+Negative&display=swap" rel="stylesheet">
</head>
<body>

<?php
        echo '<h2>Récapitulatif de votre commande :</h2>';
        echo '<table>';
        echo '<tr>';
        echo '<th>ID Article</th>';
        echo '<th>Nom de l\'article</th>';
        echo '<th>Quantité demandée</th>';
        echo '</tr>';

        $total_panier = 0;
        $TOTO = array();

        foreach ($_SESSION['panier'] as $item) {
            $id_art = $item['id_art'];
            $quantite = $item['quantite'];

            $query = $bdd->prepare('SELECT id_art, nom, prix, ID_STRIPE FROM jeux WHERE id_art = :id_art');
            $query->bindParam(':id_art', $id_art, PDO::PARAM_INT);
            $query->execute();
            $article = $query->fetch(PDO::FETCH_ASSOC);

            if ($article) {
                echo '<tr>';
                echo '<td>' . $article['id_art'] . '</td>';
                echo '<td>' . $article['nom'] . '</td>';
                echo '<td>' . $quantite . '</td>';
                echo '</tr>';

                $prix_unitaire = $article['prix'];
                $total_panier += $prix_unitaire * $quantite;

                $TOTO[] = [
                    'price' => $article['ID_STRIPE'],
                    'quantity' => $quantite,
                ];
            }
        }
        echo '</table>';

        echo '<p>Montant de votre commande : ' . $total_panier . '€</p>';

        if ($total_panier > 0) {
            echo '<p>La commande sera expédiée à l’adresse suivante :</p>';
            echo '<p>' . $id_client['prenom'] . ' ' . $id_client['nom'] . '</p>';
            echo '<p>' . $id_client['adresse'] . '</p>';

            // Crée une session de paiement avec Stripe
            $checkout_session = $stripe->checkout->sessions->create([
                'customer' => $id_stripe_utilisateur,
                'success_url' => 'http://localhost/Benmouloud_Mehdi/acheter.php',
                'cancel_url' => 'http://localhost/Benmouloud_Mehdi/panier.php',
                'mode' => 'payment',
                'automatic_tax' => ['enabled' => false],
                'line_items' => $TOTO,
            ]);

            // Redirige vers la page de paiement
            header("HTTP/1.1 303 See Other");
            header("Location: " . $checkout_session->url);
            exit;
        } else {

            header("HTTP/1.1 303 See Other");
            header("Location: panier.php");
            exit;
        }


?>
</body>
</html>

