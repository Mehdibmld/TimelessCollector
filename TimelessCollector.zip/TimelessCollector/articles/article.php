<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TimelessCollector</title>
    <link rel="stylesheet" type="text/css" href="../styles/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Signika+Negative&display=swap" rel="stylesheet">
   
</head>
<body>
<?php
session_start();

include "../bd.php";
$bdd = getBD();

if (isset($_GET['id_art'])) {
    $id_art = $_GET['id_art'];

    $query = $bdd->prepare('SELECT nom, url_photo, description,quantite FROM jeux WHERE id_art = :id_art');
    $query->bindParam(':id_art', $id_art, PDO::PARAM_INT);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        $nom = $result['nom'];
        $url_photo = $result['url_photo'];
        $desc = $result['description'];
        $quantite = $result['quantite'];

        // Calcul de la quantité disponible pour cet article
        $quantite_panier = 0;
        if (isset($_SESSION['panier'][$id_art])) {
            $quantite_panier = $_SESSION['panier'][$id_art]['quantite'];
        }

        $quantite_disponible = $quantite - $quantite_panier;
        ?>

        <h1><?php echo $nom; ?></h1>
        <img src="<?php echo '../' . $url_photo; ?>" alt="Image de <?php echo $nom; ?>" class="couverture">
        <p><?php echo $desc; ?></p>

        <?php
        if (isset($_SESSION['client'])) {
            ?>

            <form action="../ajouter.php" method="post">
                <input type="hidden" name="id_art" value="<?php echo $id_art; ?>">
                <label for="quantite">Nombre d'exemplaires :</label>
                <input type="number" name="quantite" id="quantite" min="0" max="<?php echo $quantite_disponible; ?>" value="1">
                <input type="submit" value="Ajouter à votre panier" class="ContactBu">
            </form>

            <?php
        }
        ?>

        <br />
        <a href="../index.php" class="ContactBu">
            Retour
        </a>

        <?php
    } else {
        echo "L'article n'existe pas !";
    }
} else {
    echo "L'id de l'article n'a pas été spécifié.";
}
?>

    
</body>
</html>
