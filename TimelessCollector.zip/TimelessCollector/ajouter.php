<?php
session_start();
require_once('bd.php'); 

if (isset($_POST['id_art']) && isset($_POST['quantite'])) {
    $id_art = $_POST['id_art'];
    $quantite_panier = $_POST['quantite'];

    if (is_numeric($_POST['quantite'])) {
        $quantite_panier = intval($_POST['quantite']);
    }

    // Récupérer la quantité disponible dans la base de données
    $bdd = getBD(); 

    $query = $bdd->prepare("SELECT quantite FROM jeux WHERE id_art = ?");
    $query->execute([$id_art]);

    $result = $query->fetch(PDO::FETCH_ASSOC);
    $quantite_disponible = $result['quantite'];

    // Calculer la quantité totale dans le panier
    $quantite_panier_totale = 0;
    if (isset($_SESSION['panier'])) {
        foreach ($_SESSION['panier'] as $article) {
            if ($article['id_art'] == $id_art) {
                $quantite_panier_totale += $article['quantite'];
            }
        }
    }

    // Vérifier si la quantité dans le panier ne dépasse pas la quantité disponible
    if ($quantite_panier > 0 && ($quantite_panier_totale + $quantite_panier) <= $quantite_disponible) {
        if (!isset($_SESSION['panier'])) {
            $_SESSION['panier'] = array(
                array('id_art' => $id_art, 'quantite' => $quantite_panier)
            );
        } else {
            $nouvel_article = array('id_art' => $id_art, 'quantite' => $quantite_panier);
            array_push($_SESSION['panier'], $nouvel_article);
        }

        // Vérifier le contenu du panier
        echo "Contenu du panier :<pre>";
        print_r($_SESSION['panier']);
        echo "</pre>";

        header('Location: index.php');
        exit();
    } else {
        // Redirection avec un message d'erreur si la quantité dans le panier dépasse la quantité disponible
        header('Location: index.php?error=QuantiteDepassee');
        exit();
    }
} else {
    header('Location: index.php'); 
}
?>
