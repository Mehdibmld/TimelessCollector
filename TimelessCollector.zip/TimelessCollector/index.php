<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TimelessCollector</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Signika+Negative&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="Chat/chat.js"></script>
</head>

<body>
        <nav class="login">
          
                <?php 
                session_start();
                    if (!isset($_SESSION['client'])) { ?>
                    <a href="nouveau.php"> <button class="ContactBu">Nouveau Client</button></a> 
                    <a href="connexion.php"><button class="ContactBu">Se connecter</button></a>
                <?php } else { 
                    
                    echo '<a href="deconnexion.php?deconnexion=1"><button class="ContactBu">Se déconnecter</button></a>';
                    echo '<a href="panier.php"><button class="ContactBu">Panier</button></a>';
                    echo '<a href="historique.php"><button class="ContactBu">Historique des commandes</button></a>';
                    echo '<div class="bienvenue">Bonjour ' . $_SESSION['client']['prenom'] . ' ' . $_SESSION['client']['nom'] .",". '</div>';
                    echo '<div class="position"><iframe src="Chat/chat.html" width="300" height="300" ></iframe></div>';

                } ?>
    
        </nav>
    <a href="index.php">
        <h1 class="Titre" >TimelessCollector</h1>
    </a>
    
    <p id="Desc">Plongez dans le passé et découvrez une sélection exceptionnelle de jeux rares !</p></br>
    <table>
        <tr>
            <th>Numéro d'identification</th>
            <th>Nom du jeu</th>
            <th>Quantité en stock</th>
            <th>Prix</th>
            <th>Jeux</th>
        </tr>

        <?php
        include "bd.php";
        $bdd = getBD();
        $result = $bdd->query('SELECT id_art, nom, quantite, url_photo, prix FROM jeux');
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            echo '<tr>';
            echo '<td>' . $row['id_art'] . '</td>';
            echo '<td><a href="articles/article.php?id_art=' . $row['id_art'] . '">' . $row['nom'] . '</a></td>';
            echo '<td>' . $row['quantite'] . '</td>';
            echo '<td>' . $row['prix'] . '€</td>';
            echo '<td><img src="' . $row['url_photo'] . '"></td>';
            echo '</tr>';
        }
        ?>
    </table>

<script>
    $(document).ready(function() {
        getMessages();
    });
    $('form').submit(function(event) {
        event.preventDefault();
        postMessage();
    });
</script>
</body>
<a href="contact/contact.html" target="" class="ContactBu2">
    Contact
</a>
</html>
