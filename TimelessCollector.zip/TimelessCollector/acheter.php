<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TimelessCollector</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Signika+Negative&display=swap" rel="stylesheet">
</head>
<body>
<?php
session_start();
if (isset($_SESSION['client']) && isset($_SESSION['panier']) && !empty($_SESSION['panier'])) {
    include "bd.php";
    $bdd = getBD();

    $id_client = $_SESSION['client'];

    foreach ($_SESSION['panier'] as $item) {
        $id_art = $item['id_art'];
        $quantite = $item['quantite'];

        $insert_query = $bdd->prepare('INSERT INTO commandes (id_art, id_client, quantite, envoi) VALUES (:id_art, :id_client, :quantite, false)');
        $insert_query->bindParam(':id_art', $id_art, PDO::PARAM_INT);
        $insert_query->bindParam(':id_client', $id_client, PDO::PARAM_INT);
        $insert_query->bindParam(':quantite', $quantite, PDO::PARAM_INT);
        $insert_query->execute();

        $update_query = $bdd->prepare('UPDATE jeux SET quantite = quantite - :quantite WHERE id_art = :id_art');
        $update_query->bindParam(':id_art', $id_art, PDO::PARAM_INT);
        $update_query->bindParam(':quantite', $quantite, PDO::PARAM_INT);
        $update_query->execute();
    }

    
    unset($_SESSION['panier']); 


    echo 'Votre commande a bien été enregistrée. ';
} else {
    echo "Une erreur s'est produite. Veuillez vous assurer d'avoir des articles dans votre panier et d'être connecté.";
}
?>
<br />
<br />
<br />
<a href="index.php" target="" class="ContactBu">
    Retour
</a>

</body>
</html>