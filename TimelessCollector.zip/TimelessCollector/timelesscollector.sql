-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : sam. 09 déc. 2023 à 20:25
-- Version du serveur : 8.0.31
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `timelesscollector`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id_client` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `adresse` text NOT NULL,
  `numero` int NOT NULL,
  `mail` varchar(255) NOT NULL,
  `mdp` varchar(5000) CHARACTER SET utf32 COLLATE utf32_general_ci NOT NULL,
  `ID_STRIPE` varchar(255) NOT NULL,
  PRIMARY KEY (`id_client`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf32;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id_client`, `nom`, `prenom`, `adresse`, `numero`, `mail`, `mdp`, `ID_STRIPE`) VALUES
(12, 'Walker', 'Kyle', '782 Road of Citizens', 120948658, 'kyle.walker@gmail.com', '$2y$10$i1rX.Q/VFyCMgujonruDheunpE/h3mEZATokSJhc4AyDvTVxuRNDG', '0'),
(2, 'Alderson', 'Elliot', '145 rue des tables', 2147483647, 'elliot.alderson@yahoo.com', '$2y$10$BGmsmcU/CeiXsylR4Lv4..kVxAKWSQswVlFObeBRQxWMLapOS4Qk.', '0'),
(24, 'Benosmane', 'Yacine', 'Gare de Tokyo', 1029384756, 'ya.benosmane@gmail.com', '$2y$10$K7zDN.pztLOYUozmQshs8Om7rpj7hlmBlE88nfi2xfcRvFr/9p21.', '0'),
(26, 'Benmouloud', 'Mehdi', '13 rue des hospices ', 2147483647, 'mido.622@outlook.fr', '$2y$10$JOahBytZQKm0rUY2o3udRO8H3kVjwhWuoacrXBC6zFKf.sfM.cyoK', 'cus_P6KTgemrxOaydb'),
(13, 'Arnold', 'Alexander', '128 rue liverpool', 2147483647, 'alexander.arnold@yahoo.fr', '$2y$10$4YKPAbYH9f.sO..AZreD3.tWNzDe1jaYo5edI1b8jq/DMLN0m1dru', '0'),
(10, 'Akabane', 'Light', '14 avenue Borderland', 292828283, 'light.akabane@mail.jp', '$2y$10$2k8dJ55aYx.xt1I4ptjZ6.bsI9BrM1qtqs6TaY4/r.88f/MlL1J9G', '0'),
(9, 'Shelby', 'Thomas', '123 Birmingham', 482893940, 'shelby.thomas@yahoo.com', '$2y$10$gewwk5c6BuN8rLF43ZEvreJ8DDODHq2Ox0Zk5f5lSwicn825wk.wS', '0'),
(27, 'Cléopatre', 'Alexandre', 'Rue de Jeanne d\'arc', 93939393, 'cleo.23@yahoo.com', '$2y$10$k6qpMqbKODaz.gH/O4xnB.49YXlTinrLAWEW.eW9gjJ6GYrCA62CK', ''),
(70, 'Compte', 'A', 'Rue des roses', 2147483647, 'compteA@gmail.fr', '$2y$10$AkE5/KJypYtHFxR7mcVVN.IQJypsOP1hNQ7eVguhBgsEN5AP/p3Ou', 'cus_P9qd7PO9aZoJmo'),
(71, 'Compte', 'B', 'Rue des tournesols', 2147483647, 'compteB@gmail.fr', '$2y$10$ARMBOo4T1HbLoUeOZbQnDeMwHer4f9CRpSpZiZcF.GC1ho.qmUeoe', 'cus_P9qegQEpHitUQf'),
(42, 'Lewis', 'Siwel', 'Six Rue des Tractopelles', 2147483647, 'siwel.lewis@bing.io', '$2y$10$xQJ09deoirIdTdma6O2xi.yT7UOSIAvRU0PEJCnMtSfQIrQR3lBvK', 'cus_P9ZCtn5htg1Gjp');

-- --------------------------------------------------------

--
-- Structure de la table `commandes`
--

DROP TABLE IF EXISTS `commandes`;
CREATE TABLE IF NOT EXISTS `commandes` (
  `id_commande` int NOT NULL AUTO_INCREMENT,
  `id_art` int DEFAULT NULL,
  `id_client` int DEFAULT NULL,
  `quantite` int DEFAULT NULL,
  `envoi` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_commande`),
  KEY `id_art` (`id_art`),
  KEY `id_client` (`id_client`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf32;

--
-- Déchargement des données de la table `commandes`
--

INSERT INTO `commandes` (`id_commande`, `id_art`, `id_client`, `quantite`, `envoi`) VALUES
(33, 4, 1, 28, 0),
(32, 1, 1, 2, 0);

-- --------------------------------------------------------

--
-- Structure de la table `jeux`
--

DROP TABLE IF EXISTS `jeux`;
CREATE TABLE IF NOT EXISTS `jeux` (
  `id_art` int NOT NULL,
  `nom` varchar(100) NOT NULL,
  `quantite` int NOT NULL,
  `prix` float NOT NULL,
  `url_photo` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `ID_STRIPE` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `jeux`
--

INSERT INTO `jeux` (`id_art`, `nom`, `quantite`, `prix`, `url_photo`, `description`, `ID_STRIPE`) VALUES
(1, 'The Legend of Zelda: Majora\'s Mask (N64)', 14, 300, 'images/zelda.jpg', 'Tout commence par une chevauchée dans les bois où Link se fait déposséder de son cheval et de son ocarina par un mystérieux personnage masqué du nom de Skull Kid. Notre héros apprend par la suite de la bouche du vendeur de masques que cet être malicieux à commis un acte sacrilège en s\'emparant du masque de Majora, une relique ancestrale qui apporte la malédiction et qui avait été scellée par les anciens. Le seul moyen d\'empêcher l\'apocalypse : reprendre possession du masque en l\'espace de trois jours, avant que la comète au visage satanique n\'entre en collision avec le monde de Termina. Grâce à l\'ocarina, Link va pouvoir à son gré remonter le temps pour pouvoir revivre perpétuellement ces trois jours de fin du monde.', 'price_1OI7cnEr1gA5p2NA6dDvkKjm'),
(2, 'Paper Mario', 48, 200, 'images/mario.jpg', 'Paper Mario initie son excellente série sur Nintendo 64, où il tranche alors avec ce que l\'on connaissait à l\'époque, tant visuellement qu\'au niveau de son gameplay. Déjà à l\'aube des années 2000, on commençait à en avoir marre des suites à rallonge du plomber moustachu en salopette. Voir arriver un jeu comme Paper Mario était donc une belle bouffée d\'air frais. Toutefois, ce n\'est pas la première incartade de Mario dans le monde du RPG puisque Squaresoft nous avait déjà pondu un génial Super Mario RPG sur Super Nintendo.', 'price_1OI7dZEr1gA5p2NAnUgNNka4'),
(3, 'International Superstar Soccer 2000', 20, 160, 'images/soccer.jpg', 'SS 2000 conserve tout ce qui a fait le succès de son prédécesseur sur Nintendo 64. Hormis le mode Carrière qui permet de créer puis de faire évoluer son propre joueur, le fond comme la forme d\'ISS restent inchangés. Le jeu fait dans l\'exhaustif en proposant un mode Training, des matchs en pré-saisons, en ligue, en championnat, coupe du monde ou d\'Europe. Malgré tous ses paramètres et son côté un peu technique, ISS 2000 reste bel et bien un jeu d\'arcade. La prise en main est immédiate et les buts s\'enchaînent assez rapidement. Les commentaires, bien qu\'étant entièrement en français, s\'avèrent à la longue plutôt répétitifs et manquent considérablement de dynamisme. Des réactions comme «ils jouent bien» ou «c\'est vraiment dommage qu\'il faille un perdant» ne constituent pas vraiment une analyse très pertinente.', 'price_1OI7eCEr1gA5p2NA5bGTs6bv'),
(4, 'StarCraft 64', 0, 120, 'images/starcraft', 'Dans un futur lointain s\'affrontent trois races à l\'échelle galactique : les Terrans, une communauté de bagnards rejetés par l\'humanité et errant au travers des systèmes solaires dans leurs robustes Cuirassés, les Zergs, des insectes géants dotés d\'une conscience collective les conduisant à coloniser de nouvelles planètes, et les Protoss, des guerriers humanoïdes aux grands pouvoirs psychiques.', 'price_1OI7g0Er1gA5p2NArhTTWQAD'),
(5, 'Ultra ClayFighter Tournament Edition', 28, 800, 'images/clayfighter', 'Il s\'agit d\'un hack rom de Clay Fighter Tournament Edition réalisé par des fans passionnés. Le but de ce hack est d\'améliorer et d\'équilibrer le jeu correctement, ainsi que d\'ajouter plus de contenu, comme plus de palette de couleurs pour les personnages.', 'price_1OI7ggEr1gA5p2NAHJBrjXLw'),
(6, 'Harvest Moon 64', 16, 230, 'images/harvestmoon', 'Il s\'agit en fait d\'une simulation de vie à la ferme. Votre grand-père vient de mourir et vous voilà à la tête de l\'exploitation familiale. Un petit ranch, une étable, un poulailler et un bout de terre sont à votre disposition, mais tout est à refaire après la liquidation. Il vous faudra faire preuve d\'imagination et de savoir-faire pour pouvoir vous en sortir.', 'price_1OI7hJEr1gA5p2NAT4yqgGOW'),
(7, 'Conker\'s Bad Fur Day', 8, 230, 'images/Conker\'s.jpg', 'Conker\'s Bad Fur Day est l\'un des jeux les plus emblématiques de la Nintendo 64... Pourtant, il n\'appartient absolument pas à la ligne de éditoriale de Nintendo. Rareware, Rare pour les intimes, avant son rachat par Microsoft, a fait les beaux jours de la Nintendo 64. C\'est bien simple, sans ces développeurs de génie, la console de Nintendo n\'aurait pas eu grand chose de vraiment intéressant à proposer aux joueurs. Imaginez, Goldeneye, Perfect Dark, Diddy Kong Racing, Donkey Kong 64... Tout ça c\'est Rare !\r\n', 'price_1OI7i4Er1gA5p2NAxrxJlnyp'),
(8, 'Resident Evil 2', 20, 150, 'images/residentevil', 'L\'histoire se trame toujours à Racoon City, une petite bourgade déjà bien malmenée deux mois auparavant par une horde de zombies. Cette fois encore, le laboratoire pharmaceutique expérimental Umbrella refait des siennes et une nouvelle vague de zombies attaque la petite ville tranquille. Selon que vous choisissiez Claire ou Léon, l\'histoire sera sensiblement différente et chacun suivra son propre scénario.', 'price_1OI7imEr1gA5p2NAw4trmuYJ');

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` int NOT NULL AUTO_INCREMENT,
  `id_client` int DEFAULT NULL,
  `content` varchar(256) CHARACTER SET utf32 COLLATE utf32_general_ci DEFAULT NULL,
  `dates` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`message_id`),
  KEY `id_client` (`id_client`)
) ENGINE=MyISAM AUTO_INCREMENT=432 DEFAULT CHARSET=utf32;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`message_id`, `id_client`, `content`, `dates`) VALUES
(431, 70, 'merci a toi aussi !', '2023-12-09 20:18:48'),
(429, 70, 'je viens de passer une commande de 30 jeux !!', '2023-12-09 20:18:17'),
(430, 71, 'bravo joyeux noel !', '2023-12-09 20:18:24');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
