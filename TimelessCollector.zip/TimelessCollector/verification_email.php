<?php
require("bd.php");

function emailExists($email) {
    try {
        $bdd = getBD();
        $query = "SELECT COUNT(*) FROM clients WHERE mail = ?";
        $stmt = $bdd->prepare($query);
        $stmt->execute([$email]);
        $count = $stmt->fetchColumn();
        $bdd = null;
        return $count > 0;
    } catch (PDOException $e) {
        
        error_log("Erreur lors de la vérification de l'e-mail : " . $e->getMessage(), 0);
        return false;
    }
}


$email = $_POST['mail'];


if (emailExists($email)) {
    echo json_encode(['success' => false, 'message' => 'L\'e-mail existe déjà.']);
} else {
    echo json_encode(['success' => true, 'message' => 'L\'e-mail est disponible.']);
}
?>
