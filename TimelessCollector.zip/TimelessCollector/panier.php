<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TimelessCollector</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Signika+Negative&display=swap" rel="stylesheet">
</head>
<body>
<?php
session_start();
if (isset($_SESSION['client'])) {
    include "bd.php";
    $bdd = getBD();

    if (isset($_SESSION['panier']) && !empty($_SESSION['panier'])) { 
        echo '<table>';
        echo '<tr>';
        echo '<th>ID Article</th>';
        echo '<th>Nom de l\'article</th>';
        echo '<th>Prix unitaire</th>';
        echo '<th>Quantité demandée</th>';
        echo '<th>Prix total</th>';
        echo '</tr>';

        $total_panier = 0; // stocker le prix total du panier

        foreach ($_SESSION['panier'] as $item) {
            $id_art = $item['id_art'];
            $quantite = $item['quantite'];

            $query = $bdd->prepare('SELECT id_art, nom, prix FROM jeux WHERE id_art = :id_art');
            $query->bindParam(':id_art', $id_art, PDO::PARAM_INT);
            $query->execute();
            $article = $query->fetch(PDO::FETCH_ASSOC);

            if ($article) {
                $prix_unitaire = $article['prix'];
                $prix_total = $prix_unitaire * $quantite;
                $total_panier += $prix_total;

                echo '<tr>';
                echo '<td>' . $article['id_art'] . '</td>';
                echo '<td>' . $article['nom'] . '</td>';
                echo '<td>' . $prix_unitaire . '€</td>';
                echo '<td>' . $quantite . '</td>';
                echo '<td>' . $prix_total . '€</td>';
                echo '</tr>';
            }
        }
        echo '</table>';

        echo '<p>Prix total du panier : ' . $total_panier . '€</p>';
        
        echo '<a href="commande.php" class="valider-commande-button">Valider la commande</a>';
    } else {
        echo 'Votre panier est vide.';
    }
} else {
    echo "Vous devez être connecté pour accéder à votre panier.";
}
?>
<br />
<br />
<br />

<a href="index.php" target="" class="ContactBu">
    Retour
</a>
</body>
</html>
