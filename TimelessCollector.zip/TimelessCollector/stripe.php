<?php

require_once('./vendor/autoload.php'); 

\Stripe\Stripe::setApiKey('sk_test_51OFwv6Er1gA5p2NAbrYcqCxZxtQSaQ880mg2jg4N0jRDkq4JchG0rA6FhsH4nF6dtriErhXJubDAZvh52bM761H200BGwpSVaL'); 

$stripe = new \Stripe\StripeClient([
    'api_key' => 'sk_test_51OFwv6Er1gA5p2NAbrYcqCxZxtQSaQ880mg2jg4N0jRDkq4JchG0rA6FhsH4nF6dtriErhXJubDAZvh52bM761H200BGwpSVaL'
]);

?>
