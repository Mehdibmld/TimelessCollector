<?php
    function getBD(){
        $servername = 'localhost';
        $port = '3306';
        $username = 'root';
        $password = '';
        $dbname = 'timelesscollector';
        $bdd = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        return $bdd;
    }
?>

