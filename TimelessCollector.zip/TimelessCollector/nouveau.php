<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Croissant+One&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script>

    $(document).ready(function() {
    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    function isValidPassword(password) {
        var passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return passwordRegex.test(password);
    }

    function validateForm() {
        var nom = $('#n').val();
        var prenom = $('#p').val();
        var adresse = $('#adr').val();
        var numero = $('#num').val();
        var email = $('#mail').val();
        var password1 = $('#mdp1').val();
        var password2 = $('#mdp2').val();

        $('.error-message').text('');

        if (nom.trim() === '') {
            $('#n').removeClass('valid').addClass('invalid');
            $('#n-message').text('(veuillez entrer votre nom !)');
        } else {
            $('#n').removeClass('invalid').addClass('valid');
        }
        
        if (prenom.trim() === '') {
            $('#p').removeClass('valid').addClass('invalid');
            $('#p-message').text('(veuillez entrer votre prénom !)');
        } else {
            $('#p').removeClass('invalid').addClass('valid');
        }

        if (adresse.trim() === '') {
            $('#adr').removeClass('valid').addClass('invalid');
            $('#adr-message').text('(veuillez entrer votre adresse !)');
        } else {
            $('#adr').removeClass('invalid').addClass('valid');
        }

        if (numero.trim() === '') {
            $('#num').removeClass('valid').addClass('invalid');
            $('#num-message').text('(veuillez entrer votre numéro !)');
        } else {
            $('#num').removeClass('invalid').addClass('valid');
        }

        if (email.trim() === '' || !isValidEmail(email)) {
            $('#mail').removeClass('valid').addClass('invalid');
            $('#mail-message').text('(veuillez entrer une adresse e-mail valide !)');
        } else {
           
            $.ajax({
                type: 'POST',
                url: 'verification_email.php',
                data: { mail: email }, 
                success: function(response) {
                    var result = JSON.parse(response);
                    if (result.success) {
                    
                        $('#mail').removeClass('invalid').addClass('valid');
                        $('#mail-message').text('(L\'e-mail est disponible)').css('color', 'green');
                    } else {
                       
                        $('#mail').removeClass('valid').addClass('invalid');
                        $('#mail-message').text('(L\'e-mail existe déjà)').css('color', 'red');
                    }
                },
                error: function(error) {
     
                    console.log(error);
                }
            });
        }

        if (password1.trim() === '' || !isValidPassword(password1)) {
            $('#mdp1').removeClass('valid').addClass('invalid');
            $('#mdp1-message').text('(le mot de passe doit contenir au moins 1 lettre, 1 chiffre et 1 caractère spécial !)');
        } else {
            $('#mdp1').removeClass('invalid').addClass('valid');
        }

        if (password2.trim() === '' || password1 !== password2) {
            $('#mdp2').removeClass('valid').addClass('invalid');
            $('#mdp2-message').text('(les mots de passe ne correspondent pas !)');
        } else {
            $('#mdp2').removeClass('invalid').addClass('valid');
        }

        var isValid = $('.invalid').length === 0;

        $('input[type="submit"]').prop('disabled', !isValid);
    }

    $('#n, #p, #adr, #num, #mail, #mdp1, #mdp2').on('input', validateForm);

    $('form').submit(function(event) {
        event.preventDefault();

        // Ajout de la requête Ajax
        $.ajax({
            type: 'POST',
            url: 'enregistrement.php',
            data: $('form').serialize(),
            success: function(response) {
                var userData = $('form').serialize();  
    $.ajax({
        type: 'POST',
        url: 'connecter.php',
        data: userData,
        success: function(connectResponse) {
            setTimeout(function(){
                window.location.href='index.php';
            },1000);
            console.log(connectResponse);
        },
        error: function(connectError) {
          
            console.log(connectError);
        }
    });
            },
            error: function(error) {
              
                console.log(error);
            }
        });
    });
});
</script>
    <title>TimelessCollector</title>
</head>
<body>
    <div class="Formulaire"> 
        <a href="./index.php">
            <h1 class="Titre">TimelessCollector</h1>
        </a>
    <form action="enregistrement.php" method="post" autocomplete="on">
        <label for="n">Nom :</label>
        <input type="text" id="n" name="n" required>
        <span class="error-message" id="n-message"></span><br><br>

        <label for="p">Prénom :</label>
        <input type="text" id="p" name="p" required>
        <span class="error-message" id="p-message"></span><br><br>

        <label for="adr">Adresse :</label>
        <input type="text" id="adr" name="adr" required>
        <span class="error-message" id="adr-message"></span><br><br>

        <label for="num">Numéro de téléphone :</label>
        <input type="text" id="num" name="num" required>
        <span class="error-message" id="num-message"></span><br><br>

        <label for="mail">Adresse e-mail :</label>
        <input type="text" id="mail" name="mail" required>
        <span class="error-message" id="mail-message"></span><br><br>

        <label for="mdp1">Mot de passe :</label>
        <input type="password" id="mdp1" name="mdp1" required>
        <span class="error-message" id="mdp1-message"></span><br><br>

        <label for="mdp2">Confirmer votre mot de passe :</label>
        <input type="password" id="mdp2" name="mdp2" required>
        <span class="error-message" id="mdp2-message"></span><br><br>

        <a href="..\index.php" target="_blank">
        <input class="ContactBu2" type="submit" value="S'enregistrer" ></a>
        </form>
    </div>
</body>
</html>
