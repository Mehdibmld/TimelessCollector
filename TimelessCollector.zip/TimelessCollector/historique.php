<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TimelessCollector</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Signika+Negative&display=swap" rel="stylesheet">
    
</head>
<body>

<?php
session_start();
if (isset($_SESSION['client'])) {
    include "bd.php";
    $bdd = getBD();

    $id_client = $_SESSION['client'];

    $query = $bdd->prepare('SELECT c.id_commande, c.id_art, a.nom, a.prix, c.quantite, c.envoi
                            FROM Commandes c
                            INNER JOIN jeux a ON c.id_art = a.id_art
                            WHERE c.id_client = :id_client');
    $query->bindParam(':id_client', $id_client, PDO::PARAM_INT);
    $query->execute();

    echo '<h2>Historique des commandes :</h2>';
    echo '<table>';
    echo '<tr>';
    echo '<th>ID Commande</th>';
    echo '<th>ID Article</th>';
    echo '<th>Nom de l\'article</th>';
    echo '<th>Prix</th>';
    echo '<th>Quantité commandée</th>';
    echo '<th>État de la commande</th>';
    echo '</tr>';

    while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        echo '<tr>';
        echo '<td>' . $row['id_commande'] . '</td>';
        echo '<td>' . $row['id_art'] . '</td>';
        echo '<td>' . $row['nom'] . '</td>';
        echo '<td>' . $row['prix'] . '€</td>';
        echo '<td>' . $row['quantite'] . '</td>';
        echo '<td>' . ($row['envoi'] ? 'Envoyée' : 'Non envoyée') . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo "Vous devez être connecté pour accéder à l'historique des commandes.";
}
?>
</body>
<br />
<br />

<a href="index.php" target="" class="ContactBu">
    Retour
</a>
</html>